
import yaml
from yaml.loader import SafeLoader
import streamlit_authenticator as stauth

def hash_password(password):
    return stauth.Hasher([password]).generate()[0]

def save_user(username, name, email, hashed_password):
    with open("users.yaml", "r") as file:
        config = yaml.load(file, Loader=SafeLoader)

    config['credentials']['usernames'][username] = {
        "name": name,
        "email": email,
        "password": hashed_password
    }
    config['preauthorized']['emails'].append(email)

    with open("users.yaml", "w") as file:
        yaml.dump(config, file, default_flow_style=False)
