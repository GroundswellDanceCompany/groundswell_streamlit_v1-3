
# Groundswell Dance Company Portal

A Streamlit app for students to log in, set goals, and track training.

## Features
- Secure login/logout
- Student self-registration
- Goal and practice tracking (coming next)

## Setup
1. Install requirements:
   ```
   pip install -r requirements.txt
   ```

2. Run the app:
   ```
   streamlit run app.py
   ```

## Deployment
Push to GitHub and deploy via [Streamlit Cloud](https://streamlit.io/cloud).
