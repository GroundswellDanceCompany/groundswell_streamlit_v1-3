
import streamlit as st
import streamlit_authenticator as stauth
import yaml
from yaml.loader import SafeLoader
from utils import hash_password, save_user

# Load user credentials
with open("users.yaml", "r") as file:
    config = yaml.load(file, Loader=SafeLoader)

authenticator = stauth.Authenticate(
    config['credentials'],
    config['cookie']['name'],
    config['cookie']['key'],
    config['cookie']['expiry_days'],
    config['preauthorized']
)

# Tabs: Login or Register
tab = st.sidebar.radio("Choose", ["Login", "Register"])

if tab == "Login":
    name, authentication_status, username = authenticator.login("Login", "main")

    if authentication_status:
        authenticator.logout("Logout", "sidebar")
        st.sidebar.success(f"Welcome {name}!")
        st.title("Groundswell Dance Co. Student Portal")
        st.write("Log your practice, set goals, watch tutorials, and more.")
    elif authentication_status == False:
        st.error("Incorrect username or password")
    elif authentication_status == None:
        st.warning("Please enter your username and password")

elif tab == "Register":
    st.header("Create a New Account")
    new_name = st.text_input("Full Name")
    new_email = st.text_input("Email")
    new_username = st.text_input("Username")
    new_password = st.text_input("Password", type="password")
    if st.button("Register"):
        if new_username in config['credentials']['usernames']:
            st.error("Username already exists")
        else:
            hashed_pw = hash_password(new_password)
            save_user(new_username, new_name, new_email, hashed_pw)
            st.success("Registration successful! Please go to the Login tab.")
