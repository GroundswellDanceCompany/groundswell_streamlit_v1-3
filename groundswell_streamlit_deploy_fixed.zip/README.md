# Groundswell Goal Tracker

A personalized app for student goal tracking, built with Streamlit.

## How to run

```bash
pip install -r requirements.txt
streamlit run appcomplete.py
```

Default login:
- **Username**: teacher
- **Password**: adminpass
